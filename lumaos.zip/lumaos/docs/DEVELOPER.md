# LUMA OS Developer Documentation

## Architecture Overview

LUMA OS is built with a modular architecture consisting of four main layers:

```
┌─────────────────────────────────────────────┐
│           Voice Interface Layer             │
│  (Wake Word Detection, Speech Recognition)  │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│              AI Core Layer                  │
│   (Intent Processing, Context Management)   │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│          Safety Validation Layer            │
│    (Command Validation, Risk Assessment)    │
└─────────────────────────────────────────────┘
                    ↓
┌─────────────────────────────────────────────┐
│         Task Execution Layer                │
│  (System Automation, App Control, Files)    │
└─────────────────────────────────────────────┘
```

## Core Components

### 1. Speech Engine (`speech_engine.py`)

**Purpose**: Handles speech-to-text (STT) and text-to-speech (TTS)

**Key Features**:
- Offline speech recognition using Vosk
- Real-time audio processing with PyAudio
- Configurable TTS with pyttsx3
- Wake word detection

**API**:
```python
engine = SpeechEngine(model_path)
text = engine.listen(timeout=5)  # Listen for speech
engine.speak("Hello world")       # Speak text
engine.cleanup()                  # Clean up resources
```

**Extending**:
```python
# Add custom wake word detection
def custom_wake_word_detector(audio_stream):
    # Your implementation
    pass
```

### 2. Intent Processor (`intent_processor.py`)

**Purpose**: Parses voice commands and extracts intent

**Pattern Matching**:
```python
self.patterns = {
    'open_app': [
        r'open (\w+)',
        r'launch (\w+)',
    ],
    # Add your patterns
}
```

**Adding New Intents**:
```python
# 1. Add pattern
self.patterns['your_intent'] = [
    r'pattern one (.+)',
    r'pattern two (.+)',
]

# 2. Add to task executor
def _your_action(self, intent):
    # Implementation
    pass
```

### 3. Task Executor (`task_executor.py`)

**Purpose**: Executes system tasks based on intents

**Handler Pattern**:
```python
def execute(self, intent):
    handlers = {
        'your_action': self._your_action,
    }
    handler = handlers.get(intent['action'])
    return handler(intent)
```

**Creating Custom Tasks**:
```python
def _custom_task(self, intent):
    """Execute custom task"""
    try:
        # Your implementation
        result = do_something()
        
        return {
            'success': True,
            'message': 'Task completed',
            'data': result
        }
    except Exception as e:
        return {
            'success': False,
            'error': str(e)
        }
```

### 4. Context Manager (`context_manager.py`)

**Purpose**: Maintains conversation history and context

**Usage**:
```python
context = ContextManager(context_dir)
context.add_command("open firefox")
context.add_result(intent, result)
recent = context.get_recent_commands(5)
```

**Extending Context**:
```python
# Add custom context data
def add_user_preference(self, key, value):
    self.preferences[key] = value
    self._save_session()
```

### 5. Safety Validator (`safety_validator.py`)

**Purpose**: Validates commands for safety

**Validation Rules**:
```python
# Add custom protection
self.protected_paths.add('/custom/path')

# Add dangerous pattern
self.dangerous_patterns.append(r'dangerous_regex')
```

## Plugin System (Future)

LUMA OS is designed to support plugins:

```python
# Example plugin structure
class LUMA OSPlugin:
    def __init__(self):
        self.name = "MyPlugin"
        self.version = "1.0"
    
    def register_intents(self):
        return {
            'my_intent': [r'my pattern (.+)']
        }
    
    def handle_intent(self, intent):
        # Handle the intent
        pass
```

## API Reference

### LUMA OS Main

```python
lumaos = LUMA OS()
lumaos.start()  # Start listening
lumaos.speak("text")  # Speak text
lumaos.process_command("command")  # Process command
```

### Speech Engine

```python
# Initialize
engine = SpeechEngine(model_path)

# Listen
text = engine.listen(timeout=5)

# Speak
engine.speak("Hello")

# Cleanup
engine.cleanup()
```

### Intent Processor

```python
processor = IntentProcessor(context)
intent = processor.parse("open firefox")
# Returns: {'action': 'open_app', 'target': 'firefox', ...}
```

### Task Executor

```python
executor = TaskExecutor()
result = executor.execute(intent)
# Returns: {'success': True, 'message': '...'}
```

## Testing

### Unit Tests

```python
# Test intent processing
python3 core/intent_processor.py

# Test task execution
python3 core/task_executor.py

# Test safety validation
python3 core/safety_validator.py
```

### Integration Testing

```python
# Test full pipeline
python3 tests/test_pipeline.py
```

## Adding New Features

### 1. Add a New Command Type

**Step 1**: Add pattern to `intent_processor.py`
```python
self.patterns['play_music'] = [
    r'play (?:some )?music',
    r'play (.+) by (.+)',
]
```

**Step 2**: Add handler to `task_executor.py`
```python
def _play_music(self, intent):
    # Implementation
    subprocess.Popen(['rhythmbox'])
    return {'success': True, 'message': 'Playing music'}
```

**Step 3**: Add to handlers dict
```python
handlers = {
    'play_music': self._play_music,
    # ...
}
```

### 2. Add System Integration

```python
# Example: Calendar integration
def _check_calendar(self, intent):
    import caldav
    # Connect to calendar
    calendar = caldav.connect()
    events = calendar.get_events_today()
    
    return {
        'success': True,
        'message': f'You have {len(events)} events today',
        'events': events
    }
```

### 3. Add AI Processing

```python
# Example: Complex query handling
def _ai_query(self, intent):
    from openai import OpenAI
    
    client = OpenAI(api_key=config.api_key)
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": intent['target']}]
    )
    
    return {
        'success': True,
        'message': response.choices[0].message.content
    }
```

## Configuration

### Config File Structure

```ini
[section]
key = value
```

### Loading Config

```python
import configparser

config = configparser.ConfigParser()
config.read('~/.lumaos/config/lumaos.conf')

wake_word = config.get('speech', 'wake_word')
```

## Debugging

### Enable Debug Logging

```python
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
```

### Common Issues

1. **Speech not recognized**: Check microphone, adjust timeout
2. **App won't open**: Verify app name and path
3. **Import errors**: Activate virtual environment

## Performance Optimization

### 1. Reduce Latency
- Use smaller Vosk model
- Optimize pattern matching
- Cache common operations

### 2. Memory Management
- Limit context history size
- Clean up resources properly
- Use generators for large datasets

### 3. CPU Usage
- Use threading for parallel tasks
- Optimize regex patterns
- Profile with cProfile

## Security Best Practices

1. **Input Validation**: Always validate user input
2. **Safe Execution**: Use subprocess safely
3. **Path Sanitization**: Check paths before file operations
4. **Command Injection**: Prevent shell injection
5. **Principle of Least Privilege**: Run with minimal permissions

## Contributing

### Code Style
- Follow PEP 8
- Use type hints
- Document all functions
- Write tests for new features

### Pull Request Process
1. Fork the repository
2. Create feature branch
3. Write tests
4. Submit PR with description

## Roadmap

- [ ] Multi-language support
- [ ] Cloud LLM integration
- [ ] Plugin system
- [ ] Smart home integration
- [ ] Mobile app
- [ ] Web dashboard
- [ ] Voice training
- [ ] Custom wake words

## Resources

- [Vosk Documentation](https://alphacephei.com/vosk/)
- [PyAudio Guide](https://people.csail.mit.edu/hubert/pyaudio/)
- [pyttsx3 Docs](https://pyttsx3.readthedocs.io/)
- [Python Subprocess](https://docs.python.org/3/library/subprocess.html)

## License

MIT License - See LICENSE file
