#!/bin/bash

# LUMA OS Installation Script
# This script sets up the complete voice-first operating system

set -e

echo "======================================"
echo "  🎤 LUMA OS Installation"
echo "  Illuminating Your Digital World"
echo "======================================"
echo ""

# Check if running as root
if [ "$EUID" -eq 0 ]; then 
    echo "Please do not run as root. Use sudo where needed."
    exit 1
fi

# Update system
echo "[1/8] Updating system packages..."
sudo apt update && sudo apt upgrade -y

# Install XFCE desktop environment
echo "[2/8] Installing XFCE desktop environment..."
sudo apt install -y xfce4 xfce4-goodies lightdm

# Install core dependencies
echo "[3/8] Installing core dependencies..."
sudo apt install -y \
    python3-pip python3-venv \
    portaudio19-dev \
    pulseaudio pulseaudio-utils \
    ffmpeg \
    git \
    wmctrl xdotool \
    espeak-ng \
    firefox chromium-browser \
    thunar \
    alsa-utils

# Create Python virtual environment
echo "[4/8] Setting up Python environment..."
python3 -m venv ~/.lumaos-env
source ~/.lumaos-env/bin/activate

# Install Python packages
echo "[5/8] Installing Python AI/speech libraries..."
pip install --upgrade pip
pip install \
    vosk \
    pyaudio \
    SpeechRecognition \
    pyttsx3 \
    requests \
    psutil \
    pynput \
    python-dotenv \
    openai \
    anthropic \
    llama-cpp-python

# Download Vosk model for offline speech recognition
echo "[6/8] Downloading speech recognition model..."
mkdir -p ~/.lumaos/models
cd ~/.lumaos/models
if [ ! -d "vosk-model-small-en-us-0.15" ]; then
    wget https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
    unzip vosk-model-small-en-us-0.15.zip
    rm vosk-model-small-en-us-0.15.zip
fi
cd -

# Install LUMA OS components
echo "[7/8] Installing LUMA OS components..."
mkdir -p ~/.lumaos/{config,logs,context,scripts}
cp -r core automation ui config/* ~/.lumaos/

# Create desktop entry
echo "[8/8] Creating desktop shortcuts..."
cat > ~/.local/share/applications/lumaos.desktop << 'EOF'
[Desktop Entry]
Version=1.0
Type=Application
Name=LUMA OS
Comment=Voice-First Operating System
Exec=/home/$USER/.lumaos/lumaos-start.sh
Icon=audio-input-microphone
Terminal=false
Categories=Utility;
EOF

# Create start script
cat > ~/.lumaos/lumaos-start.sh << 'EOF'
#!/bin/bash
source ~/.lumaos-env/bin/activate
python3 ~/.lumaos/core/lumaos_main.py
EOF
chmod +x ~/.lumaos/lumaos-start.sh

# Add to PATH
if ! grep -q "lumaos" ~/.bashrc; then
    echo 'export PATH="$HOME/.lumaos/scripts:$PATH"' >> ~/.bashrc
fi

echo ""
echo "======================================"
echo "  Installation Complete!"
echo "======================================"
echo ""
echo "To start LUMA OS:"
echo "  1. Log out and select XFCE session"
echo "  2. Run: lumaos activate"
echo ""
echo "Or run directly:"
echo "  source ~/.lumaos-env/bin/activate"
echo "  python3 ~/.lumaos/core/lumaos_main.py"
echo ""

deactivate
