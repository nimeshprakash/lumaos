#!/usr/bin/env python3
"""
VoiceOS GUI Launcher
Simple graphical interface for VoiceOS
"""

import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
import queue
import sys
from pathlib import Path

# Add core to path
sys.path.insert(0, str(Path.home() / '.voiceos' / 'core'))

try:
    from voiceos_main import VoiceOS
except ImportError:
    print("Please run install.sh first")
    sys.exit(1)

class VoiceOSGUI:
    def __init__(self):
        self.window = tk.Tk()
        self.window.title("VoiceOS - Voice-First Operating System")
        self.window.geometry("600x500")
        
        # VoiceOS instance
        self.voiceos = None
        self.running = False
        
        # Create UI
        self._create_ui()
    
    def _create_ui(self):
        """Create the user interface"""
        # Header
        header = tk.Frame(self.window, bg='#2c3e50', height=80)
        header.pack(fill='x')
        
        title = tk.Label(
            header,
            text="🎤 VoiceOS",
            font=('Arial', 24, 'bold'),
            bg='#2c3e50',
            fg='white'
        )
        title.pack(pady=20)
        
        # Status frame
        status_frame = tk.Frame(self.window, bg='#ecf0f1', height=60)
        status_frame.pack(fill='x', pady=10)
        
        self.status_label = tk.Label(
            status_frame,
            text="● Inactive",
            font=('Arial', 14),
            bg='#ecf0f1',
            fg='#e74c3c'
        )
        self.status_label.pack(pady=15)
        
        # Log display
        log_label = tk.Label(self.window, text="Activity Log:", font=('Arial', 10, 'bold'))
        log_label.pack(anchor='w', padx=10, pady=(10, 0))
        
        self.log_text = scrolledtext.ScrolledText(
            self.window,
            height=15,
            font=('Courier', 9),
            bg='#1e1e1e',
            fg='#00ff00',
            wrap=tk.WORD
        )
        self.log_text.pack(fill='both', expand=True, padx=10, pady=5)
        
        # Control buttons
        button_frame = tk.Frame(self.window)
        button_frame.pack(pady=10)
        
        self.start_button = tk.Button(
            button_frame,
            text="▶ Start VoiceOS",
            font=('Arial', 12),
            bg='#27ae60',
            fg='white',
            width=15,
            command=self.start_voiceos
        )
        self.start_button.grid(row=0, column=0, padx=5)
        
        self.stop_button = tk.Button(
            button_frame,
            text="■ Stop",
            font=('Arial', 12),
            bg='#e74c3c',
            fg='white',
            width=15,
            command=self.stop_voiceos,
            state='disabled'
        )
        self.stop_button.grid(row=0, column=1, padx=5)
        
        # Initial log message
        self.log("VoiceOS GUI ready. Click 'Start VoiceOS' to begin.")
        self.log("Say 'Computer' followed by your command.")
    
    def log(self, message):
        """Add message to log"""
        self.log_text.insert(tk.END, f"{message}\n")
        self.log_text.see(tk.END)
    
    def start_voiceos(self):
        """Start VoiceOS in background thread"""
        if self.running:
            return
        
        self.running = True
        self.start_button.config(state='disabled')
        self.stop_button.config(state='normal')
        self.status_label.config(text="● Active", fg='#27ae60')
        
        self.log("\n" + "="*50)
        self.log("Starting VoiceOS...")
        self.log("="*50)
        
        # Start in thread
        thread = threading.Thread(target=self._run_voiceos, daemon=True)
        thread.start()
    
    def stop_voiceos(self):
        """Stop VoiceOS"""
        if not self.running:
            return
        
        self.running = False
        if self.voiceos:
            self.voiceos.running = False
        
        self.start_button.config(state='normal')
        self.stop_button.config(state='disabled')
        self.status_label.config(text="● Inactive", fg='#e74c3c')
        
        self.log("\n" + "="*50)
        self.log("VoiceOS stopped")
        self.log("="*50 + "\n")
    
    def _run_voiceos(self):
        """Run VoiceOS in background"""
        try:
            # Redirect output to GUI
            original_print = print
            
            def gui_print(*args, **kwargs):
                message = ' '.join(str(arg) for arg in args)
                self.window.after(0, self.log, message)
            
            # Temporarily replace print
            import builtins
            builtins.print = gui_print
            
            # Create and start VoiceOS
            self.voiceos = VoiceOS()
            self.voiceos.start()
            
            # Restore print
            builtins.print = original_print
            
        except Exception as e:
            self.window.after(0, self.log, f"Error: {e}")
            self.window.after(0, self.stop_voiceos)
    
    def run(self):
        """Start the GUI"""
        self.window.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.window.mainloop()
    
    def on_closing(self):
        """Handle window close"""
        self.stop_voiceos()
        self.window.destroy()

if __name__ == "__main__":
    app = VoiceOSGUI()
    app.run()
