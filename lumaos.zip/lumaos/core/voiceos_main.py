#!/usr/bin/env python3
"""
VoiceOS Main Engine
Voice-first operating system core
"""

import os
import sys
import json
import queue
import threading
import time
from pathlib import Path

# Core components
from speech_engine import SpeechEngine
from intent_processor import IntentProcessor
from task_executor import TaskExecutor
from context_manager import ContextManager
from safety_validator import SafetyValidator

class VoiceOS:
    def __init__(self):
        self.home = Path.home() / ".voiceos"
        self.running = False
        
        # Initialize components
        print("🎤 Initializing VoiceOS...")
        
        self.context = ContextManager(self.home / "context")
        self.speech = SpeechEngine(self.home / "models")
        self.intent = IntentProcessor(self.context)
        self.executor = TaskExecutor()
        self.safety = SafetyValidator()
        
        # Command queue
        self.command_queue = queue.Queue()
        
        print("✅ VoiceOS initialized successfully")
    
    def speak(self, text):
        """Provide voice feedback to user"""
        self.speech.speak(text)
        print(f"🔊 VoiceOS: {text}")
    
    def process_command(self, command_text):
        """Process a voice command"""
        print(f"\n📝 Command: {command_text}")
        
        # Save to context
        self.context.add_command(command_text)
        
        # Process intent
        intent = self.intent.parse(command_text)
        print(f"🎯 Intent: {intent['action']} - {intent.get('target', 'N/A')}")
        
        # Validate safety
        if not self.safety.validate(intent):
            self.speak("I cannot perform that action as it may be unsafe.")
            return
        
        # Execute task
        try:
            result = self.executor.execute(intent)
            
            if result['success']:
                self.speak(result.get('message', 'Done'))
                self.context.add_result(intent, result)
            else:
                self.speak(f"Sorry, I couldn't complete that. {result.get('error', '')}")
        
        except Exception as e:
            self.speak(f"An error occurred: {str(e)}")
            print(f"❌ Error: {e}")
    
    def listen_loop(self):
        """Continuous listening loop"""
        print("\n🎧 Listening for wake word 'Computer'...")
        print("💡 Say 'Computer' followed by your command")
        print("💡 Say 'Computer stop' to exit\n")
        
        wake_word = "computer"
        
        while self.running:
            try:
                # Listen for wake word
                text = self.speech.listen()
                
                if text and wake_word in text.lower():
                    # Extract command after wake word
                    command = text.lower().replace(wake_word, "").strip()
                    
                    if command == "stop" or command == "exit" or command == "quit":
                        self.speak("Shutting down VoiceOS. Goodbye!")
                        self.running = False
                        break
                    
                    if command:
                        self.command_queue.put(command)
                    else:
                        self.speak("Yes, how can I help?")
                
            except KeyboardInterrupt:
                self.running = False
                break
            except Exception as e:
                print(f"⚠️  Listening error: {e}")
                time.sleep(0.5)
    
    def command_processor(self):
        """Process commands from queue"""
        while self.running:
            try:
                command = self.command_queue.get(timeout=1)
                self.process_command(command)
            except queue.Empty:
                continue
            except Exception as e:
                print(f"⚠️  Processing error: {e}")
    
    def start(self):
        """Start VoiceOS"""
        self.running = True
        
        # Start command processor thread
        processor_thread = threading.Thread(target=self.command_processor, daemon=True)
        processor_thread.start()
        
        # Welcome message
        self.speak("VoiceOS activated. How can I help you today?")
        
        # Start listening
        try:
            self.listen_loop()
        except KeyboardInterrupt:
            print("\n\n👋 Shutting down...")
        finally:
            self.running = False
            self.speech.cleanup()

def main():
    """Main entry point"""
    print("""
    ╔═══════════════════════════════════════╗
    ║                                       ║
    ║          V O I C E O S                ║
    ║     Voice-First Operating System      ║
    ║                                       ║
    ╚═══════════════════════════════════════╝
    """)
    
    try:
        voiceos = VoiceOS()
        voiceos.start()
    except Exception as e:
        print(f"❌ Fatal error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
