#!/usr/bin/env python3
"""
Safety Validator - Validates commands to prevent destructive actions
"""

import re
from typing import Dict, Any
from pathlib import Path

class SafetyValidator:
    def __init__(self):
        # Dangerous patterns to block
        self.dangerous_patterns = [
            r'rm\s+-rf\s+/',
            r'rm\s+-rf\s+~',
            r'dd\s+if=.*of=/dev/sd',
            r'mkfs',
            r'format\s+/',
            r':\(\)\{\s*:\|:&\s*\};:',  # Fork bomb
        ]
        
        # Protected paths that cannot be deleted
        self.protected_paths = {
            '/',
            '/bin',
            '/boot',
            '/dev',
            '/etc',
            '/lib',
            '/proc',
            '/root',
            '/sbin',
            '/sys',
            '/usr',
            '/var',
            Path.home(),
        }
        
        # Actions that require confirmation
        self.high_risk_actions = {
            'delete_file',
            'format_disk',
            'system_shutdown',
            'install_package',
        }
    
    def validate(self, intent: Dict[str, Any]) -> bool:
        """
        Validate an intent for safety
        Returns True if safe, False if dangerous
        """
        action = intent.get('action')
        target = intent.get('target', '')
        
        # Check for dangerous shell patterns
        original_command = intent.get('original_command', '')
        if self._contains_dangerous_pattern(original_command):
            print(f"🛡️  Blocked dangerous command pattern")
            return False
        
        # Validate file deletion
        if action == 'delete_file':
            return self._validate_deletion(target)
        
        # Validate directory operations
        if action in ['delete_directory', 'format_directory']:
            return self._validate_directory_operation(target)
        
        # High-risk actions could require additional confirmation
        if action in self.high_risk_actions:
            return self._validate_high_risk(intent)
        
        # Default: allow
        return True
    
    def _contains_dangerous_pattern(self, text: str) -> bool:
        """Check if text contains dangerous command patterns"""
        for pattern in self.dangerous_patterns:
            if re.search(pattern, text):
                return True
        return False
    
    def _validate_deletion(self, target: str) -> bool:
        """Validate file deletion safety"""
        if not target:
            return False
        
        # Expand path
        try:
            path = Path(target).expanduser().resolve()
        except Exception:
            return True  # If we can't resolve it, let it fail naturally
        
        # Check if protected path
        for protected in self.protected_paths:
            protected_path = Path(protected).resolve()
            if path == protected_path or protected_path in path.parents:
                print(f"🛡️  Blocked deletion of protected path: {path}")
                return False
        
        # Check for wildcard mass deletion
        if '*' in target or '?' in target:
            print(f"🛡️  Wildcard deletion requires explicit confirmation")
            return False
        
        return True
    
    def _validate_directory_operation(self, target: str) -> bool:
        """Validate directory operations"""
        if not target:
            return False
        
        try:
            path = Path(target).expanduser().resolve()
        except Exception:
            return True
        
        # Check if protected
        for protected in self.protected_paths:
            protected_path = Path(protected).resolve()
            if path == protected_path:
                print(f"🛡️  Blocked operation on system directory: {path}")
                return False
        
        return True
    
    def _validate_high_risk(self, intent: Dict[str, Any]) -> bool:
        """
        Validate high-risk actions
        In a full implementation, this could prompt for user confirmation
        """
        action = intent.get('action')
        
        # For now, we'll allow but log
        print(f"⚠️  High-risk action: {action}")
        
        # In production, you might want to:
        # 1. Prompt for voice confirmation
        # 2. Require a PIN
        # 3. Send notification
        # 4. Log to security audit
        
        return True
    
    def get_safety_report(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a safety report for an intent
        """
        action = intent.get('action')
        target = intent.get('target', '')
        
        report = {
            'safe': True,
            'risk_level': 'low',
            'warnings': [],
            'blocked': False
        }
        
        # Assess risk level
        if action in self.high_risk_actions:
            report['risk_level'] = 'high'
            report['warnings'].append(f'High-risk action: {action}')
        
        if action == 'delete_file' and not self._validate_deletion(target):
            report['safe'] = False
            report['blocked'] = True
            report['warnings'].append('Attempted deletion of protected path')
        
        return report

# Test
if __name__ == "__main__":
    validator = SafetyValidator()
    
    test_intents = [
        # Safe
        {'action': 'open_app', 'target': 'firefox', 'original_command': 'open firefox'},
        {'action': 'create_file', 'target': 'test.txt', 'original_command': 'create file test.txt'},
        
        # Potentially dangerous
        {'action': 'delete_file', 'target': '/etc/passwd', 'original_command': 'delete /etc/passwd'},
        {'action': 'delete_file', 'target': '~/.bashrc', 'original_command': 'delete bashrc'},
        
        # Dangerous patterns
        {'action': 'unknown', 'target': None, 'original_command': 'rm -rf /'},
    ]
    
    print("🧪 Testing Safety Validator\n")
    for intent in test_intents:
        safe = validator.validate(intent)
        report = validator.get_safety_report(intent)
        
        print(f"Command: {intent['original_command']}")
        print(f"Safe: {safe}")
        print(f"Report: {report}")
        print()
