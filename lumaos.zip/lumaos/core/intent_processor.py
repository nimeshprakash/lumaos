#!/usr/bin/env python3
"""
Intent Processor - Parses voice commands and determines intent
Uses pattern matching and optional LLM for complex queries
"""

import re
import json
from typing import Dict, List, Any

class IntentProcessor:
    def __init__(self, context_manager):
        self.context = context_manager
        
        # Define intent patterns
        self.patterns = {
            # Application control
            'open_app': [
                r'open (\w+)',
                r'launch (\w+)',
                r'start (\w+)',
                r'run (\w+)',
            ],
            'close_app': [
                r'close (\w+)',
                r'quit (\w+)',
                r'exit (\w+)',
                r'kill (\w+)',
            ],
            
            # File operations
            'create_file': [
                r'create (?:a )?(?:new )?file (?:called |named )?(.+)',
                r'make (?:a )?(?:new )?file (?:called |named )?(.+)',
                r'new file (.+)',
            ],
            'delete_file': [
                r'delete (?:the )?file (.+)',
                r'remove (?:the )?file (.+)',
            ],
            'open_file': [
                r'open (?:the )?file (.+)',
                r'show (?:me )?(?:the )?file (.+)',
            ],
            
            # Directory operations
            'list_directory': [
                r'show (?:me )?(?:my )?(?:the )?(.+?)(?:folder|directory|files)?',
                r'list (?:my )?(.+?)(?:folder|directory|files)?',
                r'what\'?s in (?:my )?(.+)',
            ],
            'create_directory': [
                r'create (?:a )?(?:new )?(?:folder|directory) (?:called |named )?(.+)',
                r'make (?:a )?(?:new )?(?:folder|directory) (?:called |named )?(.+)',
            ],
            
            # Web browsing
            'web_search': [
                r'search (?:for |about )?(.+)',
                r'google (.+)',
                r'look up (.+)',
                r'find (?:information )?(?:on |about )?(.+)',
            ],
            'open_url': [
                r'(?:go to|open|visit) (?:the )?(?:website )?(.+\.com.*)',
                r'browse (?:to )?(.+\.com.*)',
            ],
            
            # System controls
            'volume_control': [
                r'(?:set |change )?volume (?:to )?(\d+)',
                r'volume (\d+)',
                r'(?:turn )?volume (up|down)',
            ],
            'screenshot': [
                r'take (?:a )?screenshot',
                r'capture (?:the )?screen',
                r'screenshot',
            ],
            'lock_screen': [
                r'lock (?:the )?(?:screen|computer)',
                r'lock it',
            ],
            
            # Information queries
            'time': [
                r'what time is it',
                r'tell (?:me )?(?:the )?time',
                r'current time',
            ],
            'date': [
                r'what\'?s (?:the )?date',
                r'tell (?:me )?(?:the )?date',
                r'today\'?s date',
            ],
            
            # Help
            'help': [
                r'help',
                r'what can you do',
                r'show (?:me )?commands',
            ],
        }
        
        # Application name mappings
        self.app_mappings = {
            'firefox': 'firefox',
            'chrome': 'chromium-browser',
            'chromium': 'chromium-browser',
            'browser': 'firefox',
            'terminal': 'xfce4-terminal',
            'console': 'xfce4-terminal',
            'files': 'thunar',
            'file manager': 'thunar',
            'explorer': 'thunar',
            'text editor': 'mousepad',
            'editor': 'mousepad',
            'notepad': 'mousepad',
            'calculator': 'gnome-calculator',
            'calc': 'gnome-calculator',
            'settings': 'xfce4-settings-manager',
        }
    
    def parse(self, command_text: str) -> Dict[str, Any]:
        """
        Parse command text and extract intent
        Returns intent dictionary with action, target, and parameters
        """
        command_lower = command_text.lower().strip()
        
        # Try to match against patterns
        for intent_type, patterns in self.patterns.items():
            for pattern in patterns:
                match = re.search(pattern, command_lower)
                if match:
                    # Extract captured groups
                    target = match.group(1) if match.groups() else None
                    
                    # Build intent
                    intent = {
                        'action': intent_type,
                        'target': target,
                        'original_command': command_text,
                        'confidence': 0.9
                    }
                    
                    # Post-process based on intent type
                    if intent_type == 'open_app' and target:
                        # Map common app names
                        intent['target'] = self.app_mappings.get(target, target)
                    
                    return intent
        
        # If no pattern matched, use fallback/LLM processing
        return self._fallback_parse(command_text)
    
    def _fallback_parse(self, command_text: str) -> Dict[str, Any]:
        """
        Fallback parser for unmatched commands
        Could integrate with LLM here for complex queries
        """
        # Simple keyword-based fallback
        lower = command_text.lower()
        
        if any(word in lower for word in ['open', 'launch', 'start', 'run']):
            # Extract app name (last word usually)
            words = command_text.split()
            target = words[-1]
            return {
                'action': 'open_app',
                'target': self.app_mappings.get(target, target),
                'original_command': command_text,
                'confidence': 0.5
            }
        
        # Unknown command
        return {
            'action': 'unknown',
            'target': None,
            'original_command': command_text,
            'confidence': 0.0,
            'suggestion': 'Try saying "help" to see available commands'
        }
    
    def get_help_text(self) -> List[str]:
        """Return list of example commands"""
        return [
            "Application Control:",
            "  - Open Firefox / Launch Terminal / Start Calculator",
            "  - Close Firefox / Quit Terminal",
            "",
            "File Operations:",
            "  - Create a file called notes.txt",
            "  - Delete the file report.pdf",
            "  - Show my documents",
            "",
            "Web Browsing:",
            "  - Search for Python tutorials",
            "  - Go to github.com",
            "",
            "System Controls:",
            "  - Set volume to 50",
            "  - Take a screenshot",
            "  - Lock screen",
            "",
            "Information:",
            "  - What time is it?",
            "  - What's the date?",
        ]

# Test
if __name__ == "__main__":
    from context_manager import ContextManager
    import tempfile
    
    temp_dir = tempfile.mkdtemp()
    context = ContextManager(temp_dir)
    processor = IntentProcessor(context)
    
    test_commands = [
        "open firefox",
        "create a file called test.txt",
        "search for linux tutorials",
        "what time is it",
        "volume 75",
        "close terminal",
    ]
    
    print("🧪 Testing Intent Processor\n")
    for cmd in test_commands:
        intent = processor.parse(cmd)
        print(f"Command: {cmd}")
        print(f"Intent: {json.dumps(intent, indent=2)}\n")
