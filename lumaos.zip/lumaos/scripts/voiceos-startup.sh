#!/bin/bash
# VoiceOS Startup Script
# Auto-start VoiceOS when XFCE loads

VOICEOS_HOME="$HOME/.voiceos"
LOG_FILE="$HOME/.voiceos/logs/startup.log"

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Log startup
echo "$(date): VoiceOS startup initiated" >> "$LOG_FILE"

# Wait for desktop to load
sleep 5

# Check if already running
if pgrep -f "voiceos_main.py" > /dev/null; then
    echo "$(date): VoiceOS already running" >> "$LOG_FILE"
    exit 0
fi

# Activate environment and start VoiceOS
source ~/.voiceos-env/bin/activate

# Start in background with GUI
python3 "$VOICEOS_HOME/ui/voiceos_gui.py" >> "$LOG_FILE" 2>&1 &

echo "$(date): VoiceOS started" >> "$LOG_FILE"
