# LUMA OS Quick Start Guide

## What is LUMA OS?

LUMA OS is a complete voice-first operating system built on Ubuntu that lets you control your computer entirely through voice commands. Say goodbye to keyboards and mice!

**LUMA** means "nimble" - just like how quickly LUMA OS responds to your voice.

## ✨ Key Features

- 🎤 **Offline Speech Recognition** - Works without internet using Vosk
- 🤖 **AI-Powered** - Intelligent intent processing
- 🛡️ **Safety First** - Validates commands to prevent damage
- 🚀 **Fast & Lightweight** - Built on XFCE desktop
- 🔧 **Extensible** - Easy to add custom commands
- 🌐 **Full App Support** - Control any Linux app, web apps, and more

## 🚀 Installation (5 Minutes)

### Step 1: Download LUMA OS
```bash
cd ~
# Place LUMA OS files here
```

### Step 2: Run Installation
```bash
cd lumaos
chmod +x install.sh
./install.sh
```

Wait 10-15 minutes for installation to complete. The installer will:
- Install XFCE desktop environment
- Install speech recognition libraries
- Download AI models
- Set up Python environment
- Configure system

### Step 3: First Launch
```bash
lumaos activate
```

Or use the GUI:
```bash
python3 ~/.lumaos/ui/lumaos_gui.py
```

## 🎯 First Commands

Try these commands to get started:

1. **"Computer, what time is it?"**
   - Tests basic functionality

2. **"Computer, open Firefox"**
   - Opens web browser

3. **"Computer, create a file called notes.txt"**
   - Creates a new file

4. **"Computer, search for Linux tutorials"**
   - Performs web search

5. **"Computer, help"**
   - Shows available commands

## 📖 Basic Usage

### Starting LUMA OS

**Method 1: Command Line**
```bash
lumaos activate
```

**Method 2: GUI Application**
- Open Applications Menu
- Find "LUMA OS"
- Click to launch

**Method 3: Auto-start**
LUMA OS can start automatically with XFCE (configured during install)

### Speaking to LUMA OS

1. Say the wake word: **"Computer"**
2. Speak your command clearly
3. Wait for response

Example: "Computer, open terminal"

### Stopping LUMA OS

Say: **"Computer, stop"**

Or press `Ctrl+C` in the terminal

## 💡 Common Commands

### Applications
```
Computer, open Firefox
Computer, launch terminal
Computer, start calculator
Computer, close Firefox
```

### Files
```
Computer, create a file called report.txt
Computer, show my documents
Computer, delete the file old-notes.txt
Computer, make a folder called projects
```

### Web
```
Computer, search for Python tutorials
Computer, go to github.com
Computer, look up weather
```

### System
```
Computer, volume 50
Computer, volume up
Computer, take a screenshot
Computer, lock screen
```

### Information
```
Computer, what time is it?
Computer, what's the date?
Computer, help
```

## 🔧 Configuration

Configuration file: `~/.lumaos/config/lumaos.conf`

### Change Wake Word
```ini
[speech]
wake_word = jarvis
```

### Adjust Voice Speed
```ini
[speech]
tts_rate = 200
```

### Set Default Apps
```ini
[system]
browser = chromium-browser
terminal = gnome-terminal
```

## 📊 Project Structure

```
lumaos/
├── core/                    # AI engine & processing
│   ├── lumaos_main.py     # Main application
│   ├── speech_engine.py    # Speech recognition
│   ├── intent_processor.py # Command parsing
│   ├── task_executor.py    # Task execution
│   ├── context_manager.py  # History tracking
│   └── safety_validator.py # Safety checks
│
├── ui/                      # User interfaces
│   └── lumaos_gui.py      # GUI application
│
├── automation/              # Automation scripts
│   └── workflows.py        # Pre-built workflows
│
├── config/                  # Configuration
│   └── lumaos.conf        # Settings file
│
├── docs/                    # Documentation
│   ├── USER_GUIDE.md       # User manual
│   ├── DEVELOPER.md        # Developer guide
│   └── COMMAND_EXAMPLES.md # Command reference
│
├── tests/                   # Test suite
│   └── test_suite.py       # Automated tests
│
├── scripts/                 # Utility scripts
│   ├── lumaos             # Quick start script
│   └── lumaos-startup.sh  # Auto-start script
│
├── install.sh              # Installation script
└── README.md               # Project overview
```

## 🧪 Testing Your Installation

Run the test suite:
```bash
cd lumaos/tests
python3 test_suite.py
```

All tests should pass ✅

## ⚡ Advanced Features

### Workflows

Run pre-built workflows:
```bash
python3 ~/.lumaos/automation/workflows.py morning
python3 ~/.lumaos/automation/workflows.py work
python3 ~/.lumaos/automation/workflows.py focus
```

### Custom Commands

Edit: `~/.lumaos/core/intent_processor.py`

Add your own patterns:
```python
self.patterns['my_command'] = [
    r'my pattern (.+)',
]
```

## 🐛 Troubleshooting

### Microphone Not Working
```bash
# Test microphone
arecord -d 5 test.wav
aplay test.wav

# Check PulseAudio
pulseaudio --check
```

### Speech Not Recognized
- Speak more clearly
- Reduce background noise
- Check microphone position
- Adjust timeout in config

### App Won't Open
- Verify app is installed
- Check app name mapping
- Try full path

### Module Import Errors
```bash
source ~/.lumaos-env/bin/activate
```

## 🎓 Learning More

### Documentation
- **User Guide**: `docs/USER_GUIDE.md`
- **Developer Guide**: `docs/DEVELOPER.md`
- **Command Examples**: `docs/COMMAND_EXAMPLES.md`

### Example Projects
1. Build a voice-controlled home automation system
2. Create voice-activated coding workflows
3. Develop custom AI assistants
4. Integrate with IoT devices

## 🤝 Getting Help

### Check Logs
```bash
tail -f ~/.lumaos/logs/lumaos.log
```

### Common Issues
- See USER_GUIDE.md troubleshooting section
- Check GitHub issues
- Review configuration file

## 🎯 Next Steps

1. ✅ Install LUMA OS
2. ✅ Try basic commands
3. ✅ Read USER_GUIDE.md
4. ✅ Customize configuration
5. ✅ Add custom commands
6. ✅ Build workflows
7. ✅ Integrate with other tools

## 📱 System Requirements

**Minimum**:
- Ubuntu 24.04 LTS
- 4GB RAM
- 10GB disk space
- Microphone
- Speakers/headphones

**Recommended**:
- 8GB RAM
- 20GB disk space
- USB microphone
- Dedicated sound card

## 🔐 Security & Privacy

- ✅ Offline speech recognition (no cloud)
- ✅ All data stays local
- ✅ Safety validation on commands
- ✅ Protected system directories
- ✅ Command audit logging

## 🚀 Performance Tips

1. Use quality microphone
2. Minimize background apps
3. Keep LUMA OS running in background
4. Use wired headset (less latency)
5. Close unused browser tabs

## 🎉 Success!

You're now ready to use LUMA OS! Start with simple commands and gradually explore more features.

**First Command Checklist**:
- [ ] "Computer, what time is it?"
- [ ] "Computer, open Firefox"
- [ ] "Computer, help"
- [ ] "Computer, create a file called test.txt"
- [ ] "Computer, search for LUMA OS"

Enjoy your voice-first computing experience! 🎤

---

*LUMA OS - Illuminating Your Digital World*
*The Future of Human-Computer Interaction*
