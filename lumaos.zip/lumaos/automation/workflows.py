#!/usr/bin/env python3
"""
LUMA OS Automation Scripts
Pre-defined workflows for common tasks
"""

import subprocess
import time
from pathlib import Path

class WorkflowAutomation:
    """Automated workflows for LUMA OS"""
    
    def __init__(self):
        self.home = Path.home()
    
    def morning_routine(self):
        """Execute morning routine"""
        print("🌅 Starting morning routine...")
        
        # 1. Open calendar
        subprocess.Popen(['xdg-open', 'https://calendar.google.com'])
        time.sleep(2)
        
        # 2. Open email
        subprocess.Popen(['xdg-open', 'https://mail.google.com'])
        time.sleep(2)
        
        # 3. Open news
        subprocess.Popen(['firefox', 'https://news.ycombinator.com'])
        time.sleep(2)
        
        # 4. Set volume to 50%
        subprocess.run(['pactl', 'set-sink-volume', '@DEFAULT_SINK@', '50%'])
        
        print("✅ Morning routine complete!")
    
    def work_setup(self):
        """Setup work environment"""
        print("💼 Setting up work environment...")
        
        # 1. Open terminal
        subprocess.Popen(['xfce4-terminal'])
        time.sleep(1)
        
        # 2. Open VS Code (if installed)
        try:
            subprocess.Popen(['code'])
            time.sleep(2)
        except FileNotFoundError:
            pass
        
        # 3. Open browser with work tabs
        subprocess.Popen(['firefox', 
                         'https://github.com',
                         'https://stackoverflow.com'])
        
        # 4. Open file manager to projects
        projects = self.home / 'Projects'
        if projects.exists():
            subprocess.Popen(['thunar', str(projects)])
        
        print("✅ Work environment ready!")
    
    def focus_mode(self):
        """Enable focus mode"""
        print("🎯 Enabling focus mode...")
        
        # 1. Close distracting applications
        apps_to_close = ['spotify', 'slack', 'discord']
        for app in apps_to_close:
            subprocess.run(['pkill', '-f', app], check=False)
        
        # 2. Enable do not disturb
        subprocess.run(['notify-send', 
                       'Focus Mode',
                       'Distractions minimized. Stay focused!'])
        
        # 3. Set volume to low
        subprocess.run(['pactl', 'set-sink-volume', '@DEFAULT_SINK@', '20%'])
        
        print("✅ Focus mode activated!")
    
    def end_of_day(self):
        """End of day cleanup"""
        print("🌙 End of day cleanup...")
        
        # 1. Save all work (for supported apps)
        subprocess.run(['notify-send', 
                       'End of Day',
                       'Remember to save your work!'])
        
        # 2. Organize downloads
        downloads = self.home / 'Downloads'
        if downloads.exists():
            # Count files
            files = list(downloads.iterdir())
            if len(files) > 20:
                subprocess.run(['notify-send',
                               'Downloads',
                               f'{len(files)} files in Downloads. Time to organize?'])
        
        # 3. Create daily backup (optional)
        # self._backup_important_files()
        
        print("✅ End of day cleanup complete!")
    
    def screenshot_workflow(self, name=None):
        """Take screenshot and save with timestamp"""
        import datetime
        
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'{name}_{timestamp}.png' if name else f'screenshot_{timestamp}.png'
        filepath = self.home / 'Pictures' / 'Screenshots'
        filepath.mkdir(parents=True, exist_ok=True)
        
        full_path = filepath / filename
        
        # Take screenshot
        subprocess.run(['scrot', str(full_path)])
        
        print(f"📸 Screenshot saved: {filename}")
        return str(full_path)
    
    def quick_note(self, content):
        """Create quick note"""
        import datetime
        
        notes_dir = self.home / 'Documents' / 'QuickNotes'
        notes_dir.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        note_file = notes_dir / f'note_{timestamp}.txt'
        
        with open(note_file, 'w') as f:
            f.write(content)
        
        print(f"📝 Note saved: {note_file.name}")
        return str(note_file)
    
    def system_maintenance(self):
        """Perform system maintenance"""
        print("🔧 Running system maintenance...")
        
        # 1. Update package list
        print("Updating package list...")
        subprocess.run(['sudo', 'apt', 'update'], check=False)
        
        # 2. Clean package cache
        print("Cleaning package cache...")
        subprocess.run(['sudo', 'apt', 'autoremove', '-y'], check=False)
        subprocess.run(['sudo', 'apt', 'autoclean'], check=False)
        
        # 3. Clear thumbnail cache
        print("Clearing thumbnail cache...")
        thumbnail_cache = self.home / '.cache' / 'thumbnails'
        if thumbnail_cache.exists():
            subprocess.run(['rm', '-rf', str(thumbnail_cache)])
        
        print("✅ System maintenance complete!")

# Command-line interface
if __name__ == "__main__":
    import sys
    
    automation = WorkflowAutomation()
    
    workflows = {
        'morning': automation.morning_routine,
        'work': automation.work_setup,
        'focus': automation.focus_mode,
        'evening': automation.end_of_day,
        'maintenance': automation.system_maintenance,
    }
    
    if len(sys.argv) < 2:
        print("Available workflows:")
        for name in workflows.keys():
            print(f"  - {name}")
        sys.exit(1)
    
    workflow_name = sys.argv[1]
    
    if workflow_name in workflows:
        workflows[workflow_name]()
    else:
        print(f"Unknown workflow: {workflow_name}")
        sys.exit(1)
