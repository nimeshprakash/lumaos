# LUMA OS User Guide

## Getting Started

### Installation

1. Clone or download LUMA OS
2. Run the installation script:
   ```bash
   cd lumaos
   chmod +x install.sh
   ./install.sh
   ```
3. Wait for installation to complete (may take 10-15 minutes)

### First Launch

**Option 1: GUI Mode**
```bash
python3 ui/lumaos_gui.py
```

**Option 2: Command Line**
```bash
source ~/.lumaos-env/bin/activate
python3 ~/.lumaos/core/lumaos_main.py
```

**Option 3: Quick Command**
```bash
lumaos activate
```

## Using LUMA OS

### Wake Word
All commands start with the wake word **"Computer"**

Example: "Computer, open Firefox"

### Basic Commands

#### Application Control
- "Computer, open Firefox"
- "Computer, launch terminal"
- "Computer, start calculator"
- "Computer, close Firefox"

#### File Operations
- "Computer, create a file called notes.txt"
- "Computer, delete the file old-report.pdf"
- "Computer, show my documents"
- "Computer, create a folder called projects"

#### Web Browsing
- "Computer, search for Python tutorials"
- "Computer, go to github.com"
- "Computer, look up weather forecast"

#### System Control
- "Computer, set volume to 50"
- "Computer, volume up"
- "Computer, take a screenshot"
- "Computer, lock screen"

#### Information
- "Computer, what time is it?"
- "Computer, what's the date?"

#### Help
- "Computer, help"
- "Computer, show commands"

## Advanced Features

### Context Awareness
LUMA OS remembers your recent commands and can provide context-aware responses.

### Safety Features
LUMA OS includes safety validation to prevent:
- Deletion of system files
- Dangerous shell commands
- Accidental mass deletions

Protected locations:
- System directories (/, /bin, /etc, /usr, etc.)
- Your home directory root
- Any path containing wildcards without confirmation

### Custom Commands
You can extend LUMA OS by editing the intent patterns in:
`~/.lumaos/core/intent_processor.py`

### Configuration
Edit settings in:
`~/.lumaos/config/lumaos.conf`

Options include:
- Wake word customization
- Voice settings (speed, volume)
- Default applications
- Safety settings
- Feature toggles

## Troubleshooting

### "No module named vosk"
Run: `source ~/.lumaos-env/bin/activate`

### Microphone not working
Check:
1. Microphone is connected and enabled
2. PulseAudio is running: `pulseaudio --check`
3. Microphone permissions in system settings

### Speech not recognized
Try:
1. Speak more clearly and slowly
2. Reduce background noise
3. Check microphone input level
4. Adjust `timeout` in config file

### Application won't open
Check:
1. Application is installed
2. Application name is correct
3. Try full path: `Computer, open /usr/bin/firefox`

## App Compatibility

### Native Linux Apps
LUMA OS can control any Linux application via:
- Direct command execution
- Window management (wmctrl)
- Desktop automation

### Web Apps
Access any web app by:
1. Opening browser: "Computer, open Firefox"
2. Navigate to site: "Computer, go to app.example.com"

### Android Apps (Optional)
Install WayDroid for Android app support:
```bash
sudo apt install waydroid
```

## Performance Tips

1. **Faster Loading**: Keep LUMA OS running in background
2. **Better Recognition**: Use a quality microphone
3. **Reduce Latency**: Use wired headset instead of Bluetooth
4. **Resource Usage**: Close unused applications

## Privacy & Security

- **Offline by Default**: Speech recognition runs locally (Vosk)
- **No Cloud**: Data stays on your computer
- **Audit Log**: All commands logged to `~/.lumaos/logs/`
- **Safety Checks**: Validates commands before execution

## Customization

### Change Wake Word
Edit `~/.lumaos/config/lumaos.conf`:
```ini
[speech]
wake_word = jarvis
```

### Modify Voice Speed
```ini
[speech]
tts_rate = 200  # Higher = faster
```

### Add Custom App Shortcuts
Edit `~/.lumaos/core/intent_processor.py`:
```python
self.app_mappings = {
    'code': 'code',  # VS Code
    'spotify': 'spotify',
    # Add your apps here
}
```

## Integration with LLMs

LUMA OS can integrate with AI models for complex queries:

1. Add API key to config:
   ```ini
   [ai]
   use_local_llm = false
   api_key = your-api-key
   ```

2. Install additional dependencies:
   ```bash
   pip install openai  # For OpenAI
   pip install anthropic  # For Claude
   ```

## Keyboard Shortcuts

When GUI is active:
- `Ctrl+Q`: Quit LUMA OS
- `Ctrl+L`: Clear log
- `Ctrl+H`: Show help

## Uninstallation

To remove LUMA OS:
```bash
rm -rf ~/.lumaos
rm -rf ~/.lumaos-env
# Remove PATH entry from ~/.bashrc
```

## Getting Help

- GitHub Issues: [Report bugs or request features]
- Documentation: Check README.md
- Logs: `~/.lumaos/logs/lumaos.log`

## Tips & Tricks

1. **Chain Commands**: "Computer, open terminal and show my downloads"
2. **Natural Language**: Use conversational phrases
3. **Be Specific**: "my documents folder" vs "documents"
4. **Background Mode**: Let LUMA OS run while working

## What's Next?

LUMA OS is extensible! Consider:
- Adding custom automation scripts
- Integrating with smart home devices
- Creating voice-activated workflows
- Building custom UI themes

Happy voice computing! 🎤
