# LUMA OS Command Examples

## Application Control

### Opening Applications
- "Computer, open Firefox"
- "Computer, launch terminal"
- "Computer, start calculator"
- "Computer, run files" (opens file manager)
- "Computer, open browser"
- "Computer, launch text editor"

### Closing Applications
- "Computer, close Firefox"
- "Computer, quit terminal"
- "Computer, exit calculator"

## File Management

### Creating Files
- "Computer, create a file called report.txt"
- "Computer, make a new file named notes.md"
- "Computer, new file shopping-list.txt"

### Opening Files
- "Computer, open the file report.txt"
- "Computer, show me the file notes.md"

### Deleting Files
- "Computer, delete the file old-report.pdf"
- "Computer, remove the file temp.txt"

### Directory Operations
- "Computer, show my documents"
- "Computer, list downloads"
- "Computer, what's in my desktop"
- "Computer, create a folder called projects"
- "Computer, make a new directory called backup"

## Web Browsing

### Search
- "Computer, search for Python tutorials"
- "Computer, google machine learning"
- "Computer, look up weather forecast"
- "Computer, find information about Linux"

### Navigate
- "Computer, go to github.com"
- "Computer, open reddit.com"
- "Computer, visit youtube.com"

## System Control

### Volume
- "Computer, set volume to 50"
- "Computer, volume 75"
- "Computer, volume up"
- "Computer, volume down"

### Screenshots
- "Computer, take a screenshot"
- "Computer, capture the screen"
- "Computer, screenshot"

### Screen Lock
- "Computer, lock screen"
- "Computer, lock the computer"
- "Computer, lock it"

## Information Queries

### Time & Date
- "Computer, what time is it?"
- "Computer, tell me the time"
- "Computer, what's the date?"
- "Computer, today's date"

### Help
- "Computer, help"
- "Computer, what can you do?"
- "Computer, show commands"

## Advanced Workflows

### Morning Routine
- "Computer, run morning routine"
  - Opens: Calendar, Email, News
  - Sets volume to 50%

### Work Setup
- "Computer, setup work environment"
  - Opens: Terminal, Code editor, GitHub
  - Opens project folder

### Focus Mode
- "Computer, enable focus mode"
  - Closes distracting apps
  - Sets low volume
  - Enables notifications

### End of Day
- "Computer, end of day"
  - Reminds to save work
  - Organizes downloads
  - System cleanup

## Tips for Better Recognition

### Do's ✅
- Speak clearly and at normal pace
- Use natural language
- Be specific with file/app names
- Start with wake word "Computer"

### Don'ts ❌
- Don't speak too fast
- Avoid background noise
- Don't use very long commands
- Don't whisper or shout

## Common Command Patterns

### Pattern: "Computer, [action] [target]"
Examples:
- "Computer, open Firefox"
- "Computer, close terminal"
- "Computer, search Python"

### Pattern: "Computer, [action] a [type] called [name]"
Examples:
- "Computer, create a file called notes.txt"
- "Computer, make a folder called projects"

### Pattern: "Computer, [action] [intensity]"
Examples:
- "Computer, volume 50"
- "Computer, brightness high"

## Troubleshooting Commands

If LUMA OS doesn't understand:

1. Try rephrasing:
   - "open Firefox" → "launch Firefox" → "start Firefox"

2. Be more specific:
   - "my files" → "my documents folder"

3. Use full names:
   - "calc" → "calculator"
   - "term" → "terminal"

4. Ask for help:
   - "Computer, help"

## Customization Examples

### Adding Custom App
Edit `~/.lumaos/core/intent_processor.py`:

```python
self.app_mappings = {
    'spotify': 'spotify',
    'vscode': 'code',
    'discord': 'discord',
}
```

Then use:
- "Computer, open Spotify"
- "Computer, launch VSCode"

### Adding Custom Commands
Edit intent patterns to add your own commands.

## Voice Command Cheat Sheet

| Category | Command | Action |
|----------|---------|--------|
| Apps | open [app] | Launch application |
| Apps | close [app] | Close application |
| Files | create file [name] | Create new file |
| Files | show [folder] | Open folder |
| Web | search [query] | Google search |
| Web | go to [url] | Open website |
| System | volume [0-100] | Set volume |
| System | screenshot | Capture screen |
| System | lock screen | Lock computer |
| Info | what time is it | Get time |
| Info | help | Show help |

## Quick Start Examples

New user? Try these in order:

1. "Computer, what time is it?"
2. "Computer, open Firefox"
3. "Computer, search for LUMA OS tutorial"
4. "Computer, create a file called test.txt"
5. "Computer, show my documents"
6. "Computer, help"

## Power User Commands

For advanced users:

- Chain operations in workflows
- Use automation scripts
- Create custom intents
- Integrate with external APIs
- Build voice-activated pipelines

## Safety Notes

LUMA OS will block:
- System file deletion
- Dangerous shell commands
- Mass file operations (wildcards)
- Unauthorized system changes

Protected:
- / (root)
- /bin, /usr, /etc
- System directories
- Home directory (with confirmation)

## Future Commands (Roadmap)

Coming soon:
- "Computer, summarize this document"
- "Computer, translate to Spanish"
- "Computer, schedule a meeting"
- "Computer, remind me in 1 hour"
- "Computer, play my workout playlist"

---

*Last updated: 2024*
*LUMA OS - Illuminating Your Digital World* 🎤
