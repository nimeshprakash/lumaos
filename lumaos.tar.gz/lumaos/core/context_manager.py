#!/usr/bin/env python3
"""
Context Manager - Maintains conversation history and context
"""

import json
import datetime
from pathlib import Path
from typing import List, Dict, Any
from collections import deque

class ContextManager:
    def __init__(self, context_dir):
        self.context_dir = Path(context_dir)
        self.context_dir.mkdir(parents=True, exist_ok=True)
        
        # In-memory context (last 50 interactions)
        self.history = deque(maxlen=50)
        
        # Session file
        self.session_file = self.context_dir / f'session_{datetime.date.today()}.json'
        
        # Load existing session if available
        self._load_session()
    
    def add_command(self, command_text: str):
        """Add a command to context"""
        entry = {
            'timestamp': datetime.datetime.now().isoformat(),
            'type': 'command',
            'text': command_text
        }
        
        self.history.append(entry)
        self._save_session()
    
    def add_result(self, intent: Dict[str, Any], result: Dict[str, Any]):
        """Add a task result to context"""
        entry = {
            'timestamp': datetime.datetime.now().isoformat(),
            'type': 'result',
            'intent': intent,
            'result': result
        }
        
        self.history.append(entry)
        self._save_session()
    
    def get_recent_commands(self, n: int = 5) -> List[str]:
        """Get the n most recent commands"""
        commands = [
            entry['text'] 
            for entry in self.history 
            if entry['type'] == 'command'
        ]
        return commands[-n:]
    
    def get_context_summary(self) -> str:
        """Get a summary of recent context"""
        if not self.history:
            return "No recent activity"
        
        recent = list(self.history)[-5:]
        summary = []
        
        for entry in recent:
            if entry['type'] == 'command':
                summary.append(f"Command: {entry['text']}")
            elif entry['type'] == 'result':
                action = entry['intent'].get('action', 'unknown')
                success = entry['result'].get('success', False)
                summary.append(f"Task: {action} - {'✓' if success else '✗'}")
        
        return '\n'.join(summary)
    
    def _load_session(self):
        """Load session from file"""
        if self.session_file.exists():
            try:
                with open(self.session_file, 'r') as f:
                    data = json.load(f)
                    self.history.extend(data.get('history', []))
            except Exception as e:
                print(f"⚠️  Could not load session: {e}")
    
    def _save_session(self):
        """Save session to file"""
        try:
            data = {
                'date': datetime.date.today().isoformat(),
                'history': list(self.history)
            }
            
            with open(self.session_file, 'w') as f:
                json.dump(data, f, indent=2)
        
        except Exception as e:
            print(f"⚠️  Could not save session: {e}")
    
    def clear_history(self):
        """Clear context history"""
        self.history.clear()
        self._save_session()

# Test
if __name__ == "__main__":
    import tempfile
    
    temp_dir = tempfile.mkdtemp()
    context = ContextManager(temp_dir)
    
    # Add some test data
    context.add_command("open firefox")
    context.add_result(
        {'action': 'open_app', 'target': 'firefox'},
        {'success': True, 'message': 'Opening firefox'}
    )
    
    context.add_command("what time is it")
    
    print("Recent commands:", context.get_recent_commands())
    print("\nContext summary:")
    print(context.get_context_summary())
