#!/usr/bin/env python3
"""
Task Executor - Executes system tasks based on parsed intents
"""

import os
import subprocess
import datetime
import shutil
from pathlib import Path
from typing import Dict, Any

class TaskExecutor:
    def __init__(self):
        self.home = Path.home()
        self.downloads = self.home / "Downloads"
        self.documents = self.home / "Documents"
        self.desktop = self.home / "Desktop"
    
    def execute(self, intent: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a task based on intent
        Returns result dictionary with success status and message
        """
        action = intent.get('action')
        target = intent.get('target')
        
        # Route to appropriate handler
        handlers = {
            'open_app': self._open_app,
            'close_app': self._close_app,
            'create_file': self._create_file,
            'delete_file': self._delete_file,
            'open_file': self._open_file,
            'list_directory': self._list_directory,
            'create_directory': self._create_directory,
            'web_search': self._web_search,
            'open_url': self._open_url,
            'volume_control': self._volume_control,
            'screenshot': self._screenshot,
            'lock_screen': self._lock_screen,
            'time': self._get_time,
            'date': self._get_date,
            'help': self._show_help,
            'unknown': self._unknown,
        }
        
        handler = handlers.get(action, self._unknown)
        
        try:
            return handler(intent)
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def _open_app(self, intent):
        """Launch an application"""
        app = intent['target']
        
        try:
            # Launch app in background
            subprocess.Popen([app], 
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
            
            return {
                'success': True,
                'message': f'Opening {app}'
            }
        except FileNotFoundError:
            return {
                'success': False,
                'error': f'Application {app} not found'
            }
    
    def _close_app(self, intent):
        """Close an application"""
        app = intent['target']
        
        try:
            # Use wmctrl to close window
            subprocess.run(['wmctrl', '-c', app], check=False)
            
            # Or use pkill as fallback
            subprocess.run(['pkill', '-f', app], check=False)
            
            return {
                'success': True,
                'message': f'Closing {app}'
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def _create_file(self, intent):
        """Create a new file"""
        filename = intent['target']
        
        # Default to Documents if no path specified
        if '/' not in filename:
            filepath = self.documents / filename
        else:
            filepath = Path(filename).expanduser()
        
        # Create parent directories if needed
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        # Create empty file
        filepath.touch()
        
        return {
            'success': True,
            'message': f'Created file {filepath.name}',
            'filepath': str(filepath)
        }
    
    def _delete_file(self, intent):
        """Delete a file"""
        filename = intent['target']
        
        # Search common locations
        search_paths = [
            self.documents / filename,
            self.downloads / filename,
            self.desktop / filename,
            Path(filename).expanduser()
        ]
        
        for path in search_paths:
            if path.exists():
                path.unlink()
                return {
                    'success': True,
                    'message': f'Deleted {path.name}'
                }
        
        return {
            'success': False,
            'error': f'File {filename} not found'
        }
    
    def _open_file(self, intent):
        """Open a file with default application"""
        filename = intent['target']
        
        # Search common locations
        search_paths = [
            self.documents / filename,
            self.downloads / filename,
            self.desktop / filename,
            Path(filename).expanduser()
        ]
        
        for path in search_paths:
            if path.exists():
                subprocess.Popen(['xdg-open', str(path)])
                return {
                    'success': True,
                    'message': f'Opening {path.name}'
                }
        
        return {
            'success': False,
            'error': f'File {filename} not found'
        }
    
    def _list_directory(self, intent):
        """List files in a directory"""
        target = intent['target'].strip()
        
        # Map common names to paths
        dir_map = {
            'documents': self.documents,
            'downloads': self.downloads,
            'desktop': self.desktop,
            'home': self.home,
        }
        
        # Get directory path
        dirpath = dir_map.get(target.lower(), self.home / target)
        
        if not dirpath.exists():
            return {
                'success': False,
                'error': f'Directory {target} not found'
            }
        
        # List files
        files = [f.name for f in dirpath.iterdir() if not f.name.startswith('.')]
        files.sort()
        
        # Open file manager
        subprocess.Popen(['thunar', str(dirpath)])
        
        return {
            'success': True,
            'message': f'Showing {len(files)} items in {target}',
            'files': files[:10]  # First 10 files
        }
    
    def _create_directory(self, intent):
        """Create a new directory"""
        dirname = intent['target']
        
        if '/' not in dirname:
            dirpath = self.documents / dirname
        else:
            dirpath = Path(dirname).expanduser()
        
        dirpath.mkdir(parents=True, exist_ok=True)
        
        return {
            'success': True,
            'message': f'Created folder {dirpath.name}'
        }
    
    def _web_search(self, intent):
        """Perform web search"""
        query = intent['target']
        url = f'https://www.google.com/search?q={query.replace(" ", "+")}'
        
        subprocess.Popen(['firefox', url])
        
        return {
            'success': True,
            'message': f'Searching for {query}'
        }
    
    def _open_url(self, intent):
        """Open a URL in browser"""
        url = intent['target']
        
        # Add https:// if not present
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
        
        subprocess.Popen(['firefox', url])
        
        return {
            'success': True,
            'message': f'Opening {url}'
        }
    
    def _volume_control(self, intent):
        """Control system volume"""
        target = intent['target']
        
        if target.isdigit():
            # Set volume to specific level
            level = int(target)
            subprocess.run(['pactl', 'set-sink-volume', '@DEFAULT_SINK@', f'{level}%'])
            return {
                'success': True,
                'message': f'Volume set to {level}%'
            }
        elif target == 'up':
            subprocess.run(['pactl', 'set-sink-volume', '@DEFAULT_SINK@', '+5%'])
            return {'success': True, 'message': 'Volume increased'}
        elif target == 'down':
            subprocess.run(['pactl', 'set-sink-volume', '@DEFAULT_SINK@', '-5%'])
            return {'success': True, 'message': 'Volume decreased'}
        
        return {'success': False, 'error': 'Invalid volume command'}
    
    def _screenshot(self, intent):
        """Take a screenshot"""
        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f'screenshot_{timestamp}.png'
        filepath = self.desktop / filename
        
        # Use scrot or gnome-screenshot
        try:
            subprocess.run(['scrot', str(filepath)])
        except FileNotFoundError:
            subprocess.run(['gnome-screenshot', '-f', str(filepath)])
        
        return {
            'success': True,
            'message': f'Screenshot saved to desktop'
        }
    
    def _lock_screen(self, intent):
        """Lock the screen"""
        subprocess.run(['xflock4'])
        
        return {
            'success': True,
            'message': 'Locking screen'
        }
    
    def _get_time(self, intent):
        """Get current time"""
        current_time = datetime.datetime.now().strftime('%I:%M %p')
        
        return {
            'success': True,
            'message': f'The time is {current_time}'
        }
    
    def _get_date(self, intent):
        """Get current date"""
        current_date = datetime.datetime.now().strftime('%A, %B %d, %Y')
        
        return {
            'success': True,
            'message': f'Today is {current_date}'
        }
    
    def _show_help(self, intent):
        """Show help information"""
        return {
            'success': True,
            'message': 'I can help you control applications, manage files, browse the web, and control system settings. Try saying things like open Firefox, create a file, or search for tutorials.'
        }
    
    def _unknown(self, intent):
        """Handle unknown commands"""
        return {
            'success': False,
            'error': 'I didn\'t understand that command',
            'suggestion': intent.get('suggestion', 'Try saying "help" for available commands')
        }

# Test
if __name__ == "__main__":
    executor = TaskExecutor()
    
    test_intents = [
        {'action': 'time', 'target': None},
        {'action': 'date', 'target': None},
        {'action': 'create_file', 'target': 'test.txt'},
    ]
    
    print("🧪 Testing Task Executor\n")
    for intent in test_intents:
        print(f"Intent: {intent}")
        result = executor.execute(intent)
        print(f"Result: {result}\n")
