#!/usr/bin/env python3
"""
Speech Engine - Handles speech-to-text and text-to-speech
"""

import os
import json
import queue
import threading
from pathlib import Path

try:
    import vosk
    import pyaudio
    import pyttsx3
except ImportError as e:
    print(f"⚠️  Missing dependency: {e}")
    print("Please run the installation script")

class SpeechEngine:
    def __init__(self, model_path):
        self.model_path = Path(model_path) / "vosk-model-small-en-us-0.15"
        
        # Initialize Vosk for speech recognition
        print("Loading speech recognition model...")
        if not self.model_path.exists():
            raise FileNotFoundError(f"Vosk model not found at {self.model_path}")
        
        self.model = vosk.Model(str(self.model_path))
        
        # Audio settings
        self.sample_rate = 16000
        self.chunk_size = 4000
        
        # Initialize PyAudio
        self.audio = pyaudio.PyAudio()
        self.stream = None
        
        # Initialize TTS engine
        print("Loading text-to-speech engine...")
        self.tts = pyttsx3.init()
        self.tts.setProperty('rate', 175)  # Speed
        self.tts.setProperty('volume', 0.9)  # Volume
        
        # Select a voice
        voices = self.tts.getProperty('voices')
        if voices:
            # Prefer female voice if available
            for voice in voices:
                if 'female' in voice.name.lower():
                    self.tts.setProperty('voice', voice.id)
                    break
        
        print("✅ Speech engine ready")
    
    def listen(self, timeout=5):
        """
        Listen for speech and convert to text
        Returns recognized text or None
        """
        try:
            # Open microphone stream
            if not self.stream or not self.stream.is_active():
                self.stream = self.audio.open(
                    format=pyaudio.paInt16,
                    channels=1,
                    rate=self.sample_rate,
                    input=True,
                    frames_per_buffer=self.chunk_size
                )
            
            # Create recognizer
            rec = vosk.KaldiRecognizer(self.model, self.sample_rate)
            rec.SetWords(True)
            
            # Listen for speech
            silence_chunks = 0
            max_silence_chunks = int(timeout * self.sample_rate / self.chunk_size)
            
            while silence_chunks < max_silence_chunks:
                data = self.stream.read(self.chunk_size, exception_on_overflow=False)
                
                if rec.AcceptWaveform(data):
                    result = json.loads(rec.Result())
                    text = result.get('text', '').strip()
                    
                    if text:
                        return text
                    
                    silence_chunks = 0
                else:
                    # Check for partial results
                    partial = json.loads(rec.PartialResult())
                    if partial.get('partial'):
                        silence_chunks = 0
                    else:
                        silence_chunks += 1
            
            # Final result after timeout
            final = json.loads(rec.FinalResult())
            text = final.get('text', '').strip()
            return text if text else None
            
        except Exception as e:
            print(f"⚠️  Speech recognition error: {e}")
            return None
    
    def speak(self, text):
        """Convert text to speech"""
        try:
            self.tts.say(text)
            self.tts.runAndWait()
        except Exception as e:
            print(f"⚠️  TTS error: {e}")
    
    def cleanup(self):
        """Clean up resources"""
        if self.stream and self.stream.is_active():
            self.stream.stop_stream()
            self.stream.close()
        
        if self.audio:
            self.audio.terminate()

# Test functionality
if __name__ == "__main__":
    import sys
    
    model_path = Path.home() / ".lumaos" / "models"
    engine = SpeechEngine(model_path)
    
    print("\n🎤 Speech Engine Test")
    print("Speak something...")
    
    try:
        text = engine.listen(timeout=10)
        if text:
            print(f"✅ Recognized: {text}")
            engine.speak(f"You said: {text}")
        else:
            print("❌ No speech detected")
    
    except KeyboardInterrupt:
        print("\n👋 Bye")
    finally:
        engine.cleanup()
