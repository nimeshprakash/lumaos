#!/usr/bin/env python3
"""
LUMA OS Test Suite
Comprehensive tests for all components
"""

import unittest
import tempfile
import sys
from pathlib import Path

# Add core to path
sys.path.insert(0, str(Path(__file__).parent.parent / 'core'))

from context_manager import ContextManager
from intent_processor import IntentProcessor
from task_executor import TaskExecutor
from safety_validator import SafetyValidator

class TestIntentProcessor(unittest.TestCase):
    """Test intent processing"""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.context = ContextManager(self.temp_dir)
        self.processor = IntentProcessor(self.context)
    
    def test_open_app(self):
        """Test opening application"""
        intent = self.processor.parse("open firefox")
        self.assertEqual(intent['action'], 'open_app')
        self.assertEqual(intent['target'], 'firefox')
    
    def test_create_file(self):
        """Test file creation intent"""
        intent = self.processor.parse("create a file called test.txt")
        self.assertEqual(intent['action'], 'create_file')
        self.assertIn('test.txt', intent['target'])
    
    def test_web_search(self):
        """Test web search intent"""
        intent = self.processor.parse("search for python tutorials")
        self.assertEqual(intent['action'], 'web_search')
        self.assertIn('python', intent['target'].lower())
    
    def test_volume_control(self):
        """Test volume control"""
        intent = self.processor.parse("volume 50")
        self.assertEqual(intent['action'], 'volume_control')
        self.assertEqual(intent['target'], '50')
    
    def test_time_query(self):
        """Test time query"""
        intent = self.processor.parse("what time is it")
        self.assertEqual(intent['action'], 'time')
    
    def test_unknown_command(self):
        """Test unknown command handling"""
        intent = self.processor.parse("xyz abc 123")
        self.assertEqual(intent['action'], 'unknown')
    
    def test_app_mapping(self):
        """Test application name mapping"""
        intent = self.processor.parse("open browser")
        self.assertEqual(intent['target'], 'firefox')

class TestSafetyValidator(unittest.TestCase):
    """Test safety validation"""
    
    def setUp(self):
        self.validator = SafetyValidator()
    
    def test_safe_command(self):
        """Test safe command passes"""
        intent = {
            'action': 'open_app',
            'target': 'firefox',
            'original_command': 'open firefox'
        }
        self.assertTrue(self.validator.validate(intent))
    
    def test_dangerous_deletion(self):
        """Test dangerous file deletion is blocked"""
        intent = {
            'action': 'delete_file',
            'target': '/etc/passwd',
            'original_command': 'delete /etc/passwd'
        }
        self.assertFalse(self.validator.validate(intent))
    
    def test_dangerous_pattern(self):
        """Test dangerous shell pattern is blocked"""
        intent = {
            'action': 'unknown',
            'target': None,
            'original_command': 'rm -rf /'
        }
        self.assertFalse(self.validator.validate(intent))
    
    def test_safe_deletion(self):
        """Test safe file deletion passes"""
        intent = {
            'action': 'delete_file',
            'target': '~/test.txt',
            'original_command': 'delete test.txt'
        }
        self.assertTrue(self.validator.validate(intent))
    
    def test_wildcard_deletion(self):
        """Test wildcard deletion is blocked"""
        intent = {
            'action': 'delete_file',
            'target': '*.txt',
            'original_command': 'delete all txt files'
        }
        self.assertFalse(self.validator.validate(intent))

class TestContextManager(unittest.TestCase):
    """Test context management"""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.context = ContextManager(self.temp_dir)
    
    def test_add_command(self):
        """Test adding command to context"""
        self.context.add_command("test command")
        recent = self.context.get_recent_commands(1)
        self.assertEqual(recent[0], "test command")
    
    def test_add_result(self):
        """Test adding result to context"""
        intent = {'action': 'test'}
        result = {'success': True}
        self.context.add_result(intent, result)
        self.assertEqual(len(list(self.context.history)), 1)
    
    def test_recent_commands(self):
        """Test getting recent commands"""
        commands = ["cmd1", "cmd2", "cmd3"]
        for cmd in commands:
            self.context.add_command(cmd)
        
        recent = self.context.get_recent_commands(2)
        self.assertEqual(len(recent), 2)
        self.assertEqual(recent[-1], "cmd3")
    
    def test_history_limit(self):
        """Test history is limited"""
        # Add more than limit
        for i in range(60):
            self.context.add_command(f"cmd{i}")
        
        # Should be limited to 50
        self.assertLessEqual(len(list(self.context.history)), 50)

class TestTaskExecutor(unittest.TestCase):
    """Test task execution"""
    
    def setUp(self):
        self.executor = TaskExecutor()
    
    def test_get_time(self):
        """Test getting time"""
        intent = {'action': 'time', 'target': None}
        result = self.executor.execute(intent)
        self.assertTrue(result['success'])
        self.assertIn('time', result['message'].lower())
    
    def test_get_date(self):
        """Test getting date"""
        intent = {'action': 'date', 'target': None}
        result = self.executor.execute(intent)
        self.assertTrue(result['success'])
        self.assertIn('date', result['message'].lower())
    
    def test_unknown_action(self):
        """Test unknown action handling"""
        intent = {'action': 'unknown', 'target': None}
        result = self.executor.execute(intent)
        self.assertFalse(result['success'])
    
    def test_create_file(self):
        """Test file creation"""
        temp_dir = tempfile.mkdtemp()
        intent = {
            'action': 'create_file',
            'target': f'{temp_dir}/test.txt'
        }
        result = self.executor.execute(intent)
        self.assertTrue(result['success'])
        self.assertTrue(Path(temp_dir, 'test.txt').exists())

class TestIntegration(unittest.TestCase):
    """Integration tests"""
    
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.context = ContextManager(self.temp_dir)
        self.processor = IntentProcessor(self.context)
        self.executor = TaskExecutor()
        self.validator = SafetyValidator()
    
    def test_full_pipeline_safe(self):
        """Test full pipeline with safe command"""
        # Parse
        intent = self.processor.parse("what time is it")
        
        # Validate
        safe = self.validator.validate(intent)
        self.assertTrue(safe)
        
        # Execute
        result = self.executor.execute(intent)
        self.assertTrue(result['success'])
    
    def test_full_pipeline_blocked(self):
        """Test full pipeline with blocked command"""
        # Parse
        intent = self.processor.parse("delete /etc/passwd")
        
        # Validate
        safe = self.validator.validate(intent)
        self.assertFalse(safe)
    
    def test_context_preservation(self):
        """Test context is preserved across commands"""
        # Execute multiple commands
        commands = [
            "open firefox",
            "what time is it",
            "create file test.txt"
        ]
        
        for cmd in commands:
            intent = self.processor.parse(cmd)
            self.context.add_command(cmd)
        
        # Check context
        recent = self.context.get_recent_commands(3)
        self.assertEqual(len(recent), 3)

def run_tests():
    """Run all tests"""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add test classes
    suite.addTests(loader.loadTestsFromTestCase(TestIntentProcessor))
    suite.addTests(loader.loadTestsFromTestCase(TestSafetyValidator))
    suite.addTests(loader.loadTestsFromTestCase(TestContextManager))
    suite.addTests(loader.loadTestsFromTestCase(TestTaskExecutor))
    suite.addTests(loader.loadTestsFromTestCase(TestIntegration))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # Return exit code
    return 0 if result.wasSuccessful() else 1

if __name__ == '__main__':
    sys.exit(run_tests())
