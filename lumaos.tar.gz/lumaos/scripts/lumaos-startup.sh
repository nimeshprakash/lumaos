#!/bin/bash
# LUMA OS Startup Script
# Auto-start LUMA OS when XFCE loads

LUMAOS_HOME="$HOME/.lumaos"
LOG_FILE="$HOME/.lumaos/logs/startup.log"

# Create log directory
mkdir -p "$(dirname "$LOG_FILE")"

# Log startup
echo "$(date): LUMA OS startup initiated" >> "$LOG_FILE"

# Wait for desktop to load
sleep 5

# Check if already running
if pgrep -f "lumaos_main.py" > /dev/null; then
    echo "$(date): LUMA OS already running" >> "$LOG_FILE"
    exit 0
fi

# Activate environment and start LUMA OS
source ~/.lumaos-env/bin/activate

# Start in background with GUI
python3 "$LUMAOS_HOME/ui/lumaos_gui.py" >> "$LOG_FILE" 2>&1 &

echo "$(date): LUMA OS started" >> "$LOG_FILE"
